"""Pretend to be the phone: python fake_phone.py ws://HOST:8000/ws/device TOKEN screenshot.png
Waits for ANALYZE on the dashboard, then sends the image. Tests backend+dashboard without Android."""
import asyncio, sys, cv2, websockets
async def main(url, token, path):
    img = cv2.imread(path); data = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 85])[1].tobytes()
    async with websockets.connect(f"{url}?token={token}") as ws:
        print("connected; press ANALYZE on dashboard")
        async for m in ws:
            if "analyze" in m: await ws.send(data); print("frame sent")
asyncio.run(main(*sys.argv[1:4]))
