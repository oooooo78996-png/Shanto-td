# Live Screen Chart Analysis (Android + Web)

Visual analysis of a candlestick chart you show on your phone. It describes visible structure
(trend, swing support/resistance). It does NOT predict price, has no proven accuracy, and
verdict `NO CLEAR ANALYSIS` is returned whenever the evidence is weak. Binary options can lose 100% of stake.

## Status: TESTED vs NOT TESTED
| Component | Status |
|---|---|
| `analysis.py`: candles, trend, swing S/R, gating | TESTED on synthetic phone-style screenshots (grid, buttons, price tag, green text, stray green icons, JPEG q85, 540px and 1080px-wide): up, down, flat, noise, black |
| `hub.py`: token check, analyze forwarding, unsolicited-frame rejection, bad frame, timeout, dead device socket, stale-socket drop | TESTED (`python tests/test_pipeline.py`) |
| `server.py` handler logic | TESTED only against a STUB of FastAPI (`tests/test_server_adapter.py`). Real FastAPI/uvicorn NOT run |
| Dashboard JS | Syntax checked (`node --check`). NOT rendered in a browser |
| Kotlin sources, manifest, Gradle files | Static review + scripted consistency checks (manifest<->classes, permissions, imports, AGP<->Gradle versions, API call order) ONLY. NOT compiled, APK NOT built, Gradle sync NOT run |
| MediaProjection capture, WebSocket from phone, JPEG encode on device | NOT RUN on any device or emulator |
| Detection on real Quotex screenshots | NOT TESTED. Thresholds are assumptions |
| TLS / wss | NOT TESTED |

## 1. Backend
    cd backend && python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python tests/test_pipeline.py            # must print ALL TESTS PASSED
    PAIR_TOKEN=choose-a-long-secret uvicorn server:app --host 0.0.0.0 --port 8000
Open http://SERVER_IP:8000, paste the token, Connect.

## 2-3. Build the APK and test the phone connection
See **QUICKSTART.md** (step-by-step).
Backend-only test without Android: `python tools/fake_phone.py ws://SERVER_IP:8000/ws/device TOKEN screenshot.png`, then press ANALYZE on the dashboard.

## Known limitations
- Apps/pages that set FLAG_SECURE capture black; result will be NO CLEAR ANALYSIS (not fixable, by Android design).
- The virtual display exists for the whole session (Android requires it); frames are dropped without encoding or sending until ANALYZE. The capture notification stays visible.
- On a static screen no new frame may arrive; the dashboard reports a timeout after 10 s.
- No OCR: levels are pixel positions, and the 30 s timeframe is not verified. Single frame per press, so no multi-frame confirmation.
- Assumes green=up/red=down on a dark theme. Confidence is a visual-quality score (max 0.80), not a win probability.
- The token is the only authentication; one phone and shared dashboards per server.
- Incognito/private browser tabs and secure apps capture black. Rotating the phone is not handled (restart the session).
- The pairing token travels in the WebSocket URL query string, so it can appear in proxy/server logs. Use a long random token, rotate it, and use wss://.
- Densely packed candles that blur together can be dropped by the width filter; the result then degrades to NO CLEAR ANALYSIS rather than a guess.
