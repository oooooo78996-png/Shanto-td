import os, secrets
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from hub import Hub
TOKEN = os.environ.get("PAIR_TOKEN") or secrets.token_urlsafe(12)
print("PAIRING TOKEN:", TOKEN)
app = FastAPI(); hub = Hub(TOKEN)

@app.get("/")
def index(): return FileResponse(os.path.join(os.path.dirname(__file__), "static/index.html"))

@app.websocket("/ws/dash")
async def dash(ws: WebSocket, token: str = ""):
    if not hub.ok(token): await ws.close(code=4401); return     # before accept -> HTTP 403
    await ws.accept(); await hub.add_dash(ws)
    try:
        while True:
            m = await ws.receive()                              # dict; tolerant of text/bytes/disconnect
            if m["type"] == "websocket.disconnect": break
            if m.get("text"): await hub.on_dash_msg(ws, m["text"])
    except WebSocketDisconnect: pass
    finally: hub.dash.discard(ws)

@app.websocket("/ws/device")
async def device(ws: WebSocket, token: str = ""):
    if not hub.ok(token): await ws.close(code=4401); return
    await ws.accept(); await hub.set_device(ws)
    try:
        while True:
            m = await ws.receive()
            if m["type"] == "websocket.disconnect": break
            if m.get("bytes"): await hub.on_frame(m["bytes"])
    except WebSocketDisconnect: pass
    finally: await hub.drop_device(ws)
