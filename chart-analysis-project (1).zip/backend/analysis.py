"""Visual chart analysis. Describes what is VISIBLE; it does not predict outcomes."""
import cv2, numpy as np, base64, time

def _masks(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    g = cv2.inRange(hsv, (35, 60, 60), (95, 255, 255))
    r = cv2.inRange(hsv, (0, 60, 60), (12, 255, 255)) | cv2.inRange(hsv, (168, 60, 60), (180, 255, 255))
    return g, r

def _main_run(c):
    """Keep the longest evenly-spaced run of shapes (the chart); drops stray icons/text glyphs."""
    c = sorted(c, key=lambda k: k["x"])
    if len(c) < 3: return c
    mw = np.median([k["w"] for k in c]); dd = []
    for k in c:                                   # one shape per x position; keep the taller
        if dd and k["x"] - dd[-1]["x"] < 0.8 * mw + 1:
            if k["low"] - k["high"] > dd[-1]["low"] - dd[-1]["high"]: dd[-1] = k
        else: dd.append(k)
    if len(dd) < 3: return dd
    med = float(np.median(np.diff([k["x"] for k in dd]))); runs = [[dd[0]]]
    for a, b in zip(dd, dd[1:]):
        if b["x"] - a["x"] > 3 * med: runs.append([b])
        else: runs[-1].append(b)
    return max(runs, key=len)

def detect_candles(img):
    H, W = img.shape[:2]; out = []
    for mask, d in zip(_masks(img), ("up", "down")):
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((5, 1), np.uint8))
        n, _, st, _ = cv2.connectedComponentsWithStats(mask)
        for i in range(1, n):
            x, y, w, h, a = st[i]
            if 2 <= w <= W * 0.04 and 4 <= h <= H * 0.5 and a >= 8:
                rows = (mask[y:y + h, x:x + w] > 0).sum(1)
                body = np.where(rows >= 0.6 * rows.max())[0]
                bt, bb = y + body.min(), y + body.max()
                out.append(dict(x=x + w / 2, w=w, high=y, low=y + h, bt=bt, bb=bb, dir=d))
    if len(out) < 5: return sorted(out, key=lambda c: c["x"])
    mw = np.median([c["w"] for c in out])          # reject UI blobs with odd widths
    out = [c for c in out if 0.5 * mw <= c["w"] <= 1.6 * mw]
    return _main_run(out)

def pivots(ys, kind, k=2):
    """Swing points. y grows downward, so a price high is a local MIN of y."""
    f = min if kind == "high" else max
    return [i for i in range(k, len(ys) - k) if ys[i] == f(ys[i - k:i + k + 1])]

def levels(ys, idx, tol):
    """Cluster swing points; a level needs >=2 pivots at least 5 candles apart."""
    pts = sorted((ys[i], i) for i in idx); groups = []
    for y, i in pts:
        if groups and y - groups[-1][-1][0] <= tol: groups[-1].append((y, i))
        else: groups.append([(y, i)])
    out = []
    for g in groups:
        ii = sorted(i for _, i in g)
        if len(ii) >= 2 and ii[-1] - ii[0] >= 5: out.append((float(np.mean([y for y, _ in g])), len(ii)))
    return out

def analyze(img):
    t = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
    H, W = img.shape[:2]; ev = []; lim = [
        "Image-based only: no price scale/OCR, so levels are pixel positions, not prices.",
        "Timeframe (30s) is NOT verified from the image; the user must confirm it.",
        "Describes the visible past; it is not a forecast and has no proven accuracy.",
        "Candle colors assumed green=up / red=down; other themes may fail."]
    c = detect_candles(img)
    res = dict(timestamp=t, verdict="NO CLEAR ANALYSIS", confidence=0.0, evidence=ev, limitations=lim, candles=len(c))
    ann = img.copy()
    for k in c:
        cv2.rectangle(ann, (int(k["x"] - k["w"] / 2), int(k["high"])), (int(k["x"] + k["w"] / 2), int(k["low"])),
                      (0, 255, 0) if k["dir"] == "up" else (0, 0, 255), 1)
    ev.append(f"Detected {len(c)} candles ({sum(k['dir']=='up' for k in c)} up / {sum(k['dir']=='down' for k in c)} down).")
    if len(c) < 15:
        ev.append("Fewer than 15 candles detected: chart not visible, wrong colors, or screen blocked (black frame)."); return _fin(res, ann)
    xs = np.array([k["x"] for k in c]); gaps = np.diff(xs); reg = float(np.median(gaps) / (gaps.std() + np.median(gaps) + 1e-9))
    ev.append(f"Spacing regularity {reg:.2f} (1.0 = evenly spaced).")
    if reg < 0.6:
        ev.append("Candle spacing irregular: detections probably include non-candle shapes."); return _fin(res, ann)
    close = np.array([k["bt"] if k["dir"] == "up" else k["bb"] for k in c], float); price = -close
    rng = max(k["low"] for k in c) - min(k["high"] for k in c)
    i = np.arange(len(c)); m, b = np.polyfit(i, price, 1); fit = m * i + b
    r2 = float(1 - ((price - fit) ** 2).sum() / (((price - price.mean()) ** 2).sum() + 1e-9))
    move = m * len(c) / (rng + 1e-9)
    ev.append(f"Linear fit of closes: net move {move*100:+.1f}% of visible range, R²={r2:.2f}.")
    tol = 0.02 * rng
    lo_, hi_ = [k["low"] for k in c], [k["high"] for k in c]
    sup = levels(lo_, pivots(lo_, "low"), tol); res_ = levels(hi_, pivots(hi_, "high"), tol)
    for y, n in sup: cv2.line(ann, (0, int(y)), (W, int(y)), (255, 200, 0), 1); ev.append(f"Support zone ~y={y:.0f}px ({n} swing touches).")
    for y, n in res_: cv2.line(ann, (0, int(y)), (W, int(y)), (255, 0, 255), 1); ev.append(f"Resistance zone ~y={y:.0f}px ({n} swing touches).")
    last = close[-1]; near = [kind for kind, L in (("resistance", res_), ("support", sup)) if any(abs(y - last) <= tol for y, _ in L)]
    if abs(move) >= 0.25 and r2 >= 0.5:
        res["verdict"] = "UPTREND (visible)" if move > 0 else "DOWNTREND (visible)"
    elif abs(move) < 0.1 and r2 < 0.3 and (sup or res_):
        res["verdict"] = "SIDEWAYS / RANGE (visible)"
    else:
        ev.append("Trend strength/fit insufficient for a clear read."); return _fin(res, ann)
    if (move > 0 and "resistance" in near) or (move < 0 and "support" in near):
        ev.append(f"Last close sits at {near[0]} against the trend: conflicting signals."); res["verdict"] = "NO CLEAR ANALYSIS"; return _fin(res, ann)
    res["confidence"] = round(min(0.8, 0.3 * r2 + 0.3 * reg + 0.2 * min(len(c) / 40, 1) + 0.2 * min(abs(move) / 0.6, 1)), 2)
    lim.append("Confidence = visual-structure quality score (max 0.80), NOT probability of winning.")
    return _fin(res, ann)

def _fin(res, ann):
    res["annotated"] = base64.b64encode(cv2.imencode(".jpg", ann)[1]).decode(); return res
