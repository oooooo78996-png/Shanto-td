"""Exercises server.py handlers with a STUB of fastapi (real FastAPI not installable here). Verifies handler logic only."""
import sys, os, types, asyncio, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..")); sys.path.insert(0, os.path.dirname(__file__))
class WSD(Exception): pass
fa = types.ModuleType("fastapi"); fa.WebSocket = object; fa.WebSocketDisconnect = WSD
class FA:
    routes = {}
    def get(s, p): return lambda f: f
    def websocket(s, p):
        def d(f): FA.routes[p] = f; return f
        return d
fa.FastAPI = FA; fr = types.ModuleType("fastapi.responses"); fr.FileResponse = lambda p: p
sys.modules.update({"fastapi": fa, "fastapi.responses": fr}); os.environ["PAIR_TOKEN"] = "t"
import server; from test_pipeline import screenshot, jpg
class S:
    def __init__(s): s.out = []; s.closed = None; s.accepted = False
    async def accept(s): s.accepted = True
    async def close(s, code=1000): s.closed = code
    async def send_text(s, t): s.out.append(json.loads(t))
class Dev(S):
    async def receive(s):
        for _ in range(100):
            if s.out: break
            await asyncio.sleep(0.02)
        if s.out and not getattr(s, "sent", 0): s.sent = 1; return {"type": "websocket.receive", "bytes": jpg(screenshot(-6))}
        await asyncio.sleep(0.3); return {"type": "websocket.disconnect"}
class Dash(S):
    n = 0
    async def receive(s):
        s.n += 1
        if s.n == 1: await asyncio.sleep(0.2); return {"type": "websocket.receive", "text": '{"cmd":"analyze"}'}
        for _ in range(100):
            if any(m.get("type") == "result" for m in s.out): break
            await asyncio.sleep(0.05)
        return {"type": "websocket.disconnect"}
async def main():
    bad = S(); await FA.routes["/ws/dash"](bad, token="x"); assert bad.closed == 4401 and not bad.accepted
    bad = S(); await FA.routes["/ws/device"](bad, token=""); assert bad.closed == 4401
    dv, ds = Dev(), Dash()
    await asyncio.gather(FA.routes["/ws/device"](dv, token="t"), FA.routes["/ws/dash"](ds, token="t"))
    assert dv.accepted and any(m.get("type") == "result" and m["verdict"].startswith("UPTREND") for m in ds.out), ds.out
    assert server.hub.dev is None and not server.hub.dash
    print("ADAPTER TESTS PASSED (stubbed FastAPI)")
asyncio.run(main())
