import asyncio, json, sys, os, cv2, numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hub import Hub
from analysis import analyze

def screenshot(drift, seed=1):
    """Phone-like 540x1200 screen: status bar, grid, candles, price line/tag, big UP/DOWN buttons."""
    rng = np.random.default_rng(seed); im = np.full((1200, 540, 3), (30, 24, 20), np.uint8)
    cv2.rectangle(im, (0, 0), (540, 40), (50, 40, 35), -1); cv2.putText(im, "12:30", (10, 28), 0, 0.8, (230, 230, 230), 2)
    for y in range(100, 800, 70): cv2.line(im, (0, y), (540, y), (60, 55, 50), 1)
    p = 500
    for k in range(40):
        o = p; c = p + drift + rng.normal(0, 4); hi = min(o, c) - rng.integers(4, 10); lo = max(o, c) + rng.integers(4, 10); x = 30 + k * 11
        col = (80, 200, 60) if c < o else (60, 60, 220)
        cv2.line(im, (x, int(hi)), (x, int(lo)), col, 1); cv2.rectangle(im, (x - 3, int(min(o, c))), (x + 3, int(max(o, c)) + 1), col, -1); p = c
    cv2.line(im, (0, int(p)), (540, int(p)), (80, 200, 60), 1); cv2.rectangle(im, (490, int(p) - 8), (540, int(p) + 8), (80, 200, 60), -1)
    cv2.rectangle(im, (20, 1000), (260, 1100), (80, 200, 60), -1); cv2.rectangle(im, (280, 1000), (520, 1100), (60, 60, 220), -1)
    cv2.putText(im, '+86%', (400, 900), 0, 0.9, (80, 200, 60), 2)          # green payout text
    for q in range(6): cv2.rectangle(im, (100 + q * 15, 880), (110 + q * 15, 892), (80, 200, 60), -1)  # stray green icons
    return im
jpg = lambda im: cv2.imencode(".jpg", im, [cv2.IMWRITE_JPEG_QUALITY, 85])[1].tobytes()

class FW:
    def __init__(s): s.m = []
    async def send_text(s, t): s.m.append(json.loads(t))

async def main():
    # --- engine on realistic, JPEG-compressed screenshots
    for name, im, want in [("up", screenshot(-6), "UPTREND"), ("down", screenshot(6), "DOWNTREND")]:
        r = analyze(cv2.imdecode(np.frombuffer(jpg(im), np.uint8), 1)); print(name, r["verdict"], r["confidence"], r["candles"])
        assert r["verdict"].startswith(want) and 36 <= r["candles"] <= 44, r["evidence"]
    big = cv2.resize(screenshot(-6), None, fx=2, fy=2, interpolation=cv2.INTER_LINEAR)   # ~1080x2400 phone
    r = analyze(cv2.imdecode(np.frombuffer(jpg(big), np.uint8), 1)); print("up@2x", r["verdict"], r["candles"]); assert r["verdict"].startswith("UPTREND") and 36 <= r["candles"] <= 44, r["evidence"]
    r = analyze(cv2.imdecode(np.frombuffer(jpg(screenshot(0, 3)), np.uint8), 1)); print("flat", r["verdict"]); assert r["verdict"] in ("NO CLEAR ANALYSIS", "SIDEWAYS / RANGE (visible)")
    # --- hub routing
    h = Hub("tok", timeout=0.3); assert h.ok("tok") and not h.ok("bad") and not h.ok(None)
    d, p = FW(), FW(); await h.add_dash(d)
    await h.on_dash_msg(d, '{"cmd":"analyze"}'); assert "not connected" in d.m[-1]["msg"]
    await h.set_device(p); await h.on_dash_msg(d, '{"cmd":"analyze"}'); assert p.m == [{"cmd": "analyze"}] and h.pending
    await h.on_frame(jpg(screenshot(-6))); res = d.m[-1]; assert res["type"] == "result" and res["verdict"].startswith("UPTREND") and res["evidence"] and res["timestamp"]
    n = len(d.m); await h.on_frame(jpg(screenshot(-6))); assert len(d.m) == n, "unsolicited frame must be ignored"
    await h.on_dash_msg(d, '{"cmd":"analyze"}'); await h.on_frame(b"garbage"); assert "invalid" in d.m[-1]["msg"]
    await h.on_dash_msg(d, '{"cmd":"analyze"}'); await asyncio.sleep(0.5); assert "No frame" in d.m[-1]["msg"] and not h.pending
    await h.on_dash_msg(d, '{"cmd":"analyze"}'); await h.on_frame(jpg(np.zeros((1200, 540, 3), np.uint8))); assert d.m[-1]["verdict"] == "NO CLEAR ANALYSIS"
    p2 = FW(); await h.set_device(p2); n = len(d.m); await h.drop_device(p); assert h.dev is p2 and len(d.m) == n, "stale drop must not broadcast"
    class Dead:
        async def send_text(s, t): raise RuntimeError("closed")
    await h.set_device(Dead()); await h.on_dash_msg(d, '{"cmd":"analyze"}'); assert h.dev is None and not h.pending and "lost" in d.m[-1]["msg"]
    await h.set_device(p2); await h.drop_device(p2); assert h.dev is None
    print("ALL TESTS PASSED")
if __name__ == '__main__': asyncio.run(main())
