import asyncio, json, secrets, cv2, numpy as np
from analysis import analyze
MAX_FRAME = 8 * 1024 * 1024

class Hub:
    def __init__(self, token, timeout=10.0):
        self.token, self.timeout = token, timeout
        self.dev = None; self.dash = set(); self.pending = False; self._t = None
    def ok(self, t): return secrets.compare_digest((t or "").encode(), self.token.encode())
    def _clear(self):
        self.pending = False
        if self._t: self._t.cancel(); self._t = None
    async def bcast(self, m):
        for d in list(self.dash):
            try: await d.send_text(json.dumps(m))
            except Exception: self.dash.discard(d)
    async def add_dash(self, ws):
        self.dash.add(ws); await ws.send_text(json.dumps({"type": "status", "device": self.dev is not None, "msg": "Dashboard connected"}))
    async def set_device(self, ws):
        self.dev = ws; self._clear(); await self.bcast({"type": "status", "device": True, "msg": "Phone connected"})
    async def drop_device(self, ws):
        if self.dev is not ws: return          # stale socket from an earlier connection: ignore
        self.dev = None; self._clear(); await self.bcast({"type": "status", "device": False, "msg": "Phone disconnected"})
    async def on_dash_msg(self, ws, raw):
        try: m = json.loads(raw)
        except ValueError: return
        if not isinstance(m, dict) or m.get("cmd") != "analyze": return
        if self.dev is None: await ws.send_text(json.dumps({"type": "status", "device": False, "msg": "Phone not connected"})); return
        if self.pending: return
        self.pending = True
        try: await self.dev.send_text('{"cmd":"analyze"}')
        except Exception:
            self.dev = None; self._clear()
            await self.bcast({"type": "status", "device": False, "msg": "Phone connection lost"}); return
        await self.bcast({"type": "status", "device": True, "msg": "Capture requested, waiting for frame…"})
        self._t = asyncio.create_task(self._timeout())
    async def _timeout(self):
        await asyncio.sleep(self.timeout)
        if self.pending:
            self.pending = False
            await self.bcast({"type": "status", "device": True, "msg": "No frame received. Screen may be static, or capture is blocked (FLAG_SECURE / incognito / session ended)."})
    async def on_frame(self, data: bytes):
        if not self.pending: return            # unsolicited frames are ignored
        self._clear()
        img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR) if 0 < len(data) <= MAX_FRAME else None
        if img is None: await self.bcast({"type": "status", "device": True, "msg": "Received invalid/oversized frame"}); return
        try: r = await asyncio.get_running_loop().run_in_executor(None, analyze, img)
        except Exception as e: await self.bcast({"type": "status", "device": True, "msg": f"Analysis error: {type(e).__name__}"}); return
        r["type"] = "result"; r["frame_size"] = [img.shape[1], img.shape[0]]; await self.bcast(r)
