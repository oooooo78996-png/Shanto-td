# Quick start: build the APK and test phone -> web

You need: a PC with Python 3.10+, Android Studio (Koala 2024.1.1 or newer), an Android phone (Android 8+), a USB cable, internet for the first Gradle sync.

## 1. Start the backend (PC)
    cd backend
    python -m venv .venv
    .venv\Scripts\activate          (Windows)   |   source .venv/bin/activate   (Mac/Linux)
    pip install -r requirements.txt
    python tests/test_pipeline.py   (must end with ALL TESTS PASSED)
    set PAIR_TOKEN=pick-a-long-secret     (Windows cmd)  |  $env:PAIR_TOKEN="..." (PowerShell)  |  export PAIR_TOKEN=...  (Mac/Linux)
    uvicorn server:app --host 0.0.0.0 --port 8000
Leave it running. Open http://localhost:8000 in the PC browser, paste the token, click Connect.

## 2. Build the APK
1. Android Studio > File > Open > choose the `android` folder > Trust project.
2. Let Gradle sync finish (first time downloads Gradle 8.7, plugins, SDK pieces). If it asks to install "Android SDK Platform 34" or Build-Tools, click the install link and accept licenses.
3. Check File > Settings > Build, Execution, Deployment > Build Tools > Gradle > Gradle JDK = 17 or newer (the bundled JBR is fine).
4. Build > Build Bundle(s) / APK(s) > Build APK(s). Click "locate" in the popup.
   File: `android/app/build/outputs/apk/debug/app-debug.apk`
5. On the phone: Settings > About phone > tap Build number 7 times > Developer options > USB debugging ON. Plug in USB, accept the prompt.
6. Install: press the green Run button in Android Studio (easiest), or `adb install -r app-debug.apk`.
(`adb` lives in <Android SDK>/platform-tools.)

## 3. Test phone -> web (USB method, no Wi-Fi/firewall issues)
1. PC terminal: `adb reverse tcp:8000 tcp:8000`   (re-run after re-plugging the phone)
2. Phone, ChartCap app: URL `ws://localhost:8000/ws/device`, token = your token, tap "Grant capture & connect", accept the system dialog, allow notifications.
3. PC dashboard: the status must read "Phone connected (phone online)" and ANALYZE becomes enabled. That proves phone -> server -> dashboard works.
4. Put anything on the phone screen (a chart if you have one) and press ANALYZE on the dashboard.
   Within a few seconds you should get a result card with an annotated copy of your phone screen.
   A non-chart screen correctly gives NO CLEAR ANALYSIS ("Fewer than 15 candles detected"). That is a PASS for the pipeline.

Wi-Fi alternative: PC and phone on the same network, URL `ws://PC_LAN_IP:8000/ws/device`. First open http://PC_LAN_IP:8000 in the phone's browser; if that page doesn't load, allow port 8000 in the PC firewall.
Emulator: use `ws://10.0.2.2:8000/ws/device`.

## If something fails
| Symptom | Likely cause |
|---|---|
| Gradle sync error | Copy the exact message to me. Common: no internet/proxy, SDK 34 not installed, JDK < 17 |
| App says token rejected (notification) | Token mismatch with `PAIR_TOKEN` |
| Dashboard never shows "phone online" | Wrong URL/port, adb reverse not run, firewall, server not running |
| "No frame received" after 10 s | Screen static, or capture blocked (secure app / incognito) |
| Result is always NO CLEAR ANALYSIS on a real chart | Colours/size thresholds in `backend/analysis.py` need tuning; use `tools/fake_phone.py` with a screenshot to iterate |

## Gradle wrapper
`gradle/wrapper/gradle-wrapper.properties` (Gradle 8.7) is included. `gradle-wrapper.jar` and the `gradlew` scripts are binary/long files I could not obtain here (no network, none on the system), so they are NOT included. Android Studio does not need them. For command-line builds, once, with any Gradle 8.7+ installed: `cd android && gradle wrapper --gradle-version 8.7`, then `./gradlew assembleDebug` (needs ANDROID_HOME set).
