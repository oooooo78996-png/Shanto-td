plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.example.chartcap"; compileSdk = 34
  defaultConfig { applicationId = "com.example.chartcap"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
  lint { abortOnError = false } }
dependencies {
  implementation("com.squareup.okhttp3:okhttp:4.12.0")
  implementation("com.squareup.okio:okio:3.6.0")   // used directly (ByteString); matches okhttp 4.12.0
}
