package com.example.chartcap
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import okhttp3.*
import okio.ByteString.Companion.toByteString
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class CaptureService : Service() {
    @Volatile private var want = false
    @Volatile private var alive = true
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var ws: WebSocket? = null
    private var wsUrl = ""
    private var cb: MediaProjection.Callback? = null
    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private val ht = HandlerThread("cap").apply { start() }
    private val h by lazy { Handler(ht.looper) }
    override fun onBind(i: Intent?): IBinder? = null

    private fun note(text: String) {
        val n = Notification.Builder(this, "cap").setContentTitle("Chart capture").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true).build()
        getSystemService(NotificationManager::class.java).notify(1, n)
    }

    private fun release() {
        h.removeCallbacksAndMessages(null)
        ws?.close(1000, null); ws = null
        vd?.release(); vd = null
        reader?.close(); reader = null
        cb?.let { proj?.unregisterCallback(it) }; proj?.stop(); proj = null; cb = null
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        release(); alive = true; want = false
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("cap", "Capture", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cap").setContentTitle("Chart capture").setContentText("Session active, idle until ANALYZE")
            .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true).build()
        // Must be called BEFORE getMediaProjection(); the 3-arg overload exists only on API 29+.
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1, n)
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java) else i.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try { proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data) }
        catch (e: SecurityException) { note("Projection refused: ${e.message}"); stopSelf(); return START_NOT_STICKY }
        cb = object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }
        proj!!.registerCallback(cb!!, h)                      // mandatory on Android 14 before createVirtualDisplay
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION") getSystemService(android.view.WindowManager::class.java).defaultDisplay.getRealMetrics(dm)
        val r = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2); reader = r
        vd = proj!!.createVirtualDisplay("cap", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (!want) return@setOnImageAvailableListener   // dropped: not encoded, not sent
                want = false
                val p = img.planes[0]; val pad = (p.rowStride - p.pixelStride * img.width) / p.pixelStride
                val full = Bitmap.createBitmap(img.width + pad, img.height, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(p.buffer)
                val bmp = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
                val bo = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 85, bo)
                full.recycle(); bmp.recycle()
                if (ws?.send(bo.toByteArray().toByteString()) != true) note("Send failed: server not connected")
            } catch (e: Exception) { note("Capture error: ${e.javaClass.simpleName}") }
            finally { img.close() }
        }, h)
        val base = i.getStringExtra("url") ?: ""
        wsUrl = base + (if (base.contains("?")) "&" else "?") + "token=" + android.net.Uri.encode(i.getStringExtra("token") ?: "")
        connect()
        return START_NOT_STICKY
    }

    private fun connect() {
        if (!alive) return
        ws = client.newWebSocket(Request.Builder().url(wsUrl).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { note("Connected, idle until ANALYZE") }
            override fun onMessage(webSocket: WebSocket, text: String) { if (text.contains("analyze")) want = true }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(1000, null) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { if (alive) h.postDelayed({ connect() }, 3000) }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (response?.code == 403 || response?.code == 401) { note("Server rejected token"); stopSelf(); return }
                note("Reconnecting…"); if (alive) h.postDelayed({ connect() }, 3000)
            }
        })
    }

    override fun onDestroy() { alive = false; release(); ht.quitSafely(); super.onDestroy() }
}
