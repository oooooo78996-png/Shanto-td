package com.example.chartcap
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private lateinit var url: EditText; private lateinit var tok: EditText
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        url = EditText(this).apply { hint = "ws://SERVER_IP:8000/ws/device (use wss:// in production)" }
        tok = EditText(this).apply { hint = "Pairing token" }
        val start = Button(this).apply { text = "Grant capture & connect" }
        val stop = Button(this).apply { text = "Stop"; setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) } }
        val info = TextView(this).apply { text = "Open Quotex yourself, then press ANALYZE on the dashboard. Nothing is encoded or sent until you do. On Android 14+ choose 'Entire screen' (or pick your browser). Incognito tabs capture black." }
        listOf(url, tok, start, stop, info).forEach { l.addView(it) }; setContentView(l)
        start.setOnClickListener {
            if (!url.text.toString().trim().let { it.startsWith("ws://") || it.startsWith("wss://") } || tok.text.isBlank()) {
                Toast.makeText(this, "Enter a ws:// or wss:// URL and the token", Toast.LENGTH_LONG).show(); return@setOnClickListener
            }
            val mpm = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(mpm.createScreenCaptureIntent(), 42)
        }
    }
    @Deprecated("ok") override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
        super.onActivityResult(rq, rc, d)
        if (rq == 42 && rc == RESULT_OK && d != null) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", rc).putExtra("data", d)
                .putExtra("url", url.text.toString().trim()).putExtra("token", tok.text.toString().trim()))
            Toast.makeText(this, "Capture session ready. Open Quotex.", Toast.LENGTH_LONG).show()
        } else Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
    }
}
